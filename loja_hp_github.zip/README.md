# Loja HP - Calculadora

Site mobile em formato de lojinha para calcular valores do HP.

## Como publicar no GitHub Pages

1. Crie um repositório no GitHub.
2. Envie os arquivos `index.html` e `README.md` para a raiz do repositório.
3. Vá em **Settings > Pages**.
4. Em **Branch**, selecione `main` e `/root`.
5. Salve e aguarde o GitHub gerar o link do site.

Importante: o arquivo principal precisa se chamar exatamente `index.html`.
